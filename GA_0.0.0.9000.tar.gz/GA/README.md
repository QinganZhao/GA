# GA
### An R package for variable selection in regression problems based on genetic algorithm 

IMPORTANT: Please make sure you have installed 'dplyr' package 

Please also make sure you have installed the following packages if you choose parallelization: <br/>
parallel, doParallel, & foreach

While developing the package, please run the following code (in the working directory) after changing the help information: <br/>
> devtools::document() <br/>

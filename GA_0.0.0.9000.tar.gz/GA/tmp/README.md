# R-package-based-on-genetic-algorithm-for-variable-selection-in-regression-problems
The final project for UC Berkeley STAT 243
